package Client;

import Setings.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

/**
 * Created by Lenovo on 2017/01/04.
 */
public class FriendPanel extends JPanel implements MouseListener{
    private JScrollPane jsp;
    private LinkedList<JPanel> friendpanellist=new LinkedList<>();
    private LinkedList<JLabel> friendnamelist=new LinkedList<>();
    private User user;
    private int sum;
    public FriendPanel(User user){
        this.user=user;
        if(this.user.getFriendlist()==null)
            this.sum=0;
        else
            this.sum=this.user.getFriendlist().size();
        this.setLayout(new GridLayout(sum,1));

        for(int i = 0;i < sum;i ++) {
            JPanel friendpanel = new JPanel();
            friendpanel.setLayout(new FlowLayout(100, 20, 20));
            JLabel friendname = new JLabel(user.getFriendlist().get(i).getFriendId());
            friendname.setForeground(Color.RED);
            friendpanel.add(friendname);
            friendpanel.addMouseListener(this);
            friendpanel.setBorder(BorderFactory.createEtchedBorder());
            friendname.setName(user.getFriendlist().get(i).getFriendId());
            friendpanel.setName(user.getFriendlist().get(i).getFriendId());
            friendpanel.addMouseListener(this);
            this.friendnamelist.add(friendname);
            this.friendpanellist.add(friendpanel);

            this.add(friendpanel);
        }
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    public void addfriend(String friendID){
        JPanel friendpanel = new JPanel();
        friendpanel.setLayout(new FlowLayout(100,20,20));


        JLabel friendname= new JLabel(friendID);friendname.setForeground(Color.RED);

        friendpanel.add(friendname);
        friendpanel.addMouseListener(this);friendpanel.setBorder(BorderFactory.createEtchedBorder());

        friendname.setName(friendID);
        friendpanel.setName(friendID);


        this.friendnamelist.add(friendname);
        this.friendpanellist.add(friendpanel);

        sum++;
        this.setLayout(new GridLayout(sum,1));
        this.add(friendpanel);
        this.validate();
    }
    public void delfriend(String friendID){
        int num=-1;
        this.sum--;
        this.setLayout(new GridLayout(sum,1));
        for(int i=0;i<friendpanellist.size();i++){
            if(friendpanellist.get(i).getName().equals(friendID)){
                this.remove(friendpanellist.get(i));
                num=i;
                break;
            }
        }
        if(num!=-1){
            this.friendpanellist.remove(num);
            this.friendnamelist.remove(num);
        }
        this.validate();
    }
}
