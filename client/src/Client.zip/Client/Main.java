package Client;
import Setings.*;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.List;
import java.awt.Toolkit;
import java.awt.event.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
import javax.swing.event.AncestorListener;

public class Main extends JFrame implements ActionListener,MouseListener,WindowListener{



	private int sum = 10;
	private JLabel head,name,sign,pic;	//顶部设计
	private JPanel friend;
	private JScrollPane fJSP;
	private JButton add;
	private int num = 0;
	private Toolkit tool;
	private LinkedList<JLabel> friendnamelist=new LinkedList<>();
	private LinkedList<JPanel> friendpanellist=new LinkedList<>();
	private LinkedList<JLabel> touxianglist =new LinkedList<>();
	private LinkedList<JButton> deletebutton =new LinkedList<>();
	private User userinfo;

	public Main(User userinfo){
		
		this.userinfo=userinfo;
		this.setTitle(userinfo.getUsername());
		tool=this.getToolkit();
		Image img = tool.getImage("Images/head.jpg");
		
		this.setIconImage(img);
		
		pic = new JLabel(new ImageIcon("Images/tou.jpg"));
		pic.setBounds(170, 10, 60, 60);
		this.add(pic);
		
		name = new JLabel("TestUser");
		name.setBounds(10, 30, 100, 20);
		name.setFont(new Font("Serief",Font.BOLD, 16));
		name.setForeground(Color.WHITE); 
		this.add(name);
		
		sign = new JLabel("个性签名：火火火火火"); 
		sign.setBounds(20, 55, 200, 20);
		sign.setFont(new Font("宋体",Font.BOLD, 12));
		sign.setForeground(Color.WHITE); 
		this.add(sign);
		
		head = new JLabel(new ImageIcon("Images/37.jpg"));	//头
		head.setBounds(0, 0, 300, 100);
		this.add(head);
		
		setFriend();
		
		add = new JButton(" + 添加好友");
		add.setBounds(10, 330, 100, 30);
		this.add(add);
		add.addActionListener(this);
		
		this.setLayout(null);
		this.setSize(250, 400);
		this.setLocation(500, 150);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(this);
		this.setResizable(false);
		this.setVisible(true);
	}
	
	private void setFriend(){
		if(this.fJSP!=null){
			this.remove(fJSP);
			this.validate();
		}
		friend = new JPanel();
		if(this.userinfo.getFriendlist()==null)
			this.sum=0;
		else
			this.sum=this.userinfo.getFriendlist().size();
		friend.setLayout(new GridLayout(sum,1));
		fJSP = new JScrollPane(friend);
		fJSP.setBounds(0, 100, 240, 225);


		for(int i = 0;i < sum;i ++){
			JPanel friendpanel = new JPanel();
			friendpanel.setLayout(new FlowLayout(100,20,20));

			JLabel touxiang = new JLabel(new ImageIcon("Images/message.png"));
			JLabel friendname= new JLabel(userinfo.getFriendlist().get(i).getFriendId());friendname.setForeground(Color.RED);

			JButton delete = new JButton("删除");delete.addActionListener(this);
			friendpanel.add(touxiang);friendpanel.add(friendname);friendpanel.add(delete);
			friendpanel.addMouseListener(this);friendpanel.setBorder(BorderFactory.createEtchedBorder());

			friendname.setName(userinfo.getFriendlist().get(i).getFriendId());
			friendpanel.setName(userinfo.getFriendlist().get(i).getFriendId());
			touxiang.setName(userinfo.getFriendlist().get(i).getFriendId());
			delete.setName(userinfo.getFriendlist().get(i).getFriendId());
			friendpanel.addMouseListener(this);
			this.friendnamelist.add(friendname);
			this.friendpanellist.add(friendpanel);
			this.touxianglist.add(touxiang);
			this.deletebutton.add(delete);
			friend.add(friendpanel);

		}

		this.add(fJSP);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		num = e.getClickCount();
		if(num == 2){
			for(int i=0;i<friendpanellist.size();i++){
				if(friendpanellist.get(i)==e.getSource()){
					ChatRoom c=Client.client.findChatRoom(friendpanellist.get(i).getName());
					if(c==null) {
						c=new ChatRoom(userinfo, friendpanellist.get(i).getName());
						Client.client.addChatRoom(c);
						num = 0;
					}else{
						c.setVisible(true);
					}
				}
			}
		}
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == add){
			new addFriend();
		}
		for(int i = 0;i < deletebutton.size();i ++){
			if(e.getSource() == deletebutton.get(i)){
				int a = sum;
				new delWindow("确定要删除吗？",sum,this,deletebutton.get(i).getName());
			}
		}
	}

	@Override
	public void windowOpened(WindowEvent e) {

	}

	@Override
	public void windowClosing(WindowEvent e) {
		Client.client.logout();
	}

	@Override
	public void windowClosed(WindowEvent e) {

		this.dispose();

	}

	@Override
	public void windowIconified(WindowEvent e) {

	}

	@Override
	public void windowDeiconified(WindowEvent e) {

	}

	@Override
	public void windowActivated(WindowEvent e) {

	}

	@Override
	public void windowDeactivated(WindowEvent e) {

	}
	public void setUser(User user){
		this.userinfo=user;
		this.setFriend();
	}
	public void addfriend(String friendID){
		JPanel friendpanel = new JPanel();
		friendpanel.setLayout(new FlowLayout(100,20,20));

		JLabel touxiang = new JLabel(new ImageIcon("Images/message.png"));
		JLabel friendname= new JLabel(friendID);friendname.setForeground(Color.RED);

		JButton delete = new JButton("删除");delete.addActionListener(this);
		friendpanel.add(touxiang);friendpanel.add(friendname);friendpanel.add(delete);
		friendpanel.addMouseListener(this);friendpanel.setBorder(BorderFactory.createEtchedBorder());

		friendname.setName(friendID);
		friendpanel.setName(friendID);
		touxiang.setName(friendID);
		delete.setName(friendID);
		this.friendnamelist.add(friendname);
		this.friendpanellist.add(friendpanel);
		this.touxianglist.add(touxiang);
		this.deletebutton.add(delete);
		sum++;
		friend.setLayout(new GridLayout(sum,1));
		friend.add(friendpanel);
		this.validate();
	}
	public void delfriend(String friendID){
		int num=-1;
		this.sum--;
		this.friend.setLayout(new GridLayout(sum,1));
		for(int i=0;i<friendpanellist.size();i++){
			if(friendpanellist.get(i).getName().equals(friendID)){
				this.friend.remove(friendpanellist.get(i));
				num=i;
				break;
			}
		}
		if(num!=-1){
			this.friendpanellist.remove(num);
			this.friendnamelist.remove(num);
			this.touxianglist.remove(num);
			this.deletebutton.remove(num);
		}
		this.validate();
	}

}
