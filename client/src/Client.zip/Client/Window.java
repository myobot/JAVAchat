package Client;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Window extends JFrame implements ActionListener{
	/**
	 * 对话框
	 */
	private static final long serialVersionUID = 1L;
	private String str;
	private JButton jb = new JButton("确定");
	private JLabel jl = new JLabel();
	private int i = 0;
	private String friendname;
	public Window(String st,int i,String friendname){
		this.friendname=friendname;
		this.str = st;
		this.i = i;
		jl.setBounds(35, 20, 150, 50);
		jl.setText(str);
		jb.setBounds(90, 70, 70, 30);
		this.add(jb);
		this.setLayout(null);
		jb.addActionListener(this);
		this.add(jl);
		this.setSize(250, 150);
		
		this.setLocation(500, 250);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jb){
			Client.client.addFriend(friendname);
			this.dispose();
			//if(i == 1)
				//new Login();
			//if(i == 2)
				//new Typetitle();
		}
	}
}
