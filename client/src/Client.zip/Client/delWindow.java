package Client;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class delWindow extends JFrame implements ActionListener{
	/**
	 * 对话框
	 */
	private static final long serialVersionUID = 1L;
	private String str;
	private JButton jb = new JButton("是的");
	private JButton no = new JButton("再想想");
	private JLabel jl = new JLabel();
	private Main main;
	private int i = 0;
	private String friendname;
	public delWindow(String st,int i,Main main,String friendname){
		this.str = st;
		this.friendname=friendname;
		this.i = i;
		this.main = main;
		jl.setBounds(35, 20, 150, 50);
		jl.setText(str);
		jb.setBounds(145, 70, 80, 30);
		no.setBounds(20, 70, 80, 30);
		this.add(jb);
		this.add(no);
		this.setLayout(null);
		no.addActionListener(this);
		jb.addActionListener(this);
		this.add(jl);
		this.setSize(250, 150);
		
		this.setLocation(500, 250);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jb){
			Client.client.delFriend(friendname);
			this.dispose();
		}
		if(e.getSource() == no){
			this.dispose();
		}
	}
}
