package Client;
import Setings.*;
import jdk.nashorn.internal.runtime.regexp.joni.encoding.CharacterType;
import jdk.nashorn.internal.scripts.JO;

import javax.swing.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

/**
 * Created by Lenovo on 2016/12/25.
 */
public class Client {
    private ObjectInputStream netIn;
    private ObjectOutputStream netOut;
    private static Socket socket;
    private boolean runflag=true;
    public static Client client;
    private static Login loginUI;
    private static Main mainUI;
    private static User User;
    private JFrame registerframe=null;
    private JFrame loginframe=null;
    private LinkedList<ChatRoom> chatRooms=null;
    public Client(){
    }
    public void init(){
        for(int i=8888;i<10000;i++) {
            try {
//                socket = new Socket("123.206.13.201", i);
                socket = new Socket("192.168.128.1", i);
                loginUI = new Login();
                loginframe = loginUI.getFrame();
                this.netOut = new ObjectOutputStream(socket.getOutputStream());
                this.netIn = new ObjectInputStream(socket.getInputStream());
                receive();
                break;
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("端口"+i+"不可用");
            }
        }
    }
    public void receive(){
        SendBody sendBody=new SendBody();
        while(runflag) {
            if (!socket.isClosed()) {
                try {
                    if ((sendBody = (SendBody) netIn.readObject()) != null) {
                        function(sendBody);
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                    System.out.println("网络接收异常" + e1.getMessage());
                    this.logout();
                } catch (ClassNotFoundException e2) {
                    e2.printStackTrace();
                    System.out.println("找不到这个类" + e2.getMessage());
                    this.logout();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("未知异常" + e.getMessage());
                    this.logout();
                }
            }
        }
    }
    public void send(SendBody sendBody) {
        try {
            if(!socket.isClosed()) {
                this.netOut.writeObject(sendBody);
                this.netOut.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("网络输出异常" + e.getMessage());
            this.logout();
        }
    }
    public void loginreceiveorder(SendBody sendBody){
        String order=sendBody.getOrder();
        if(order.equals(Command.loginsuccess)){
            this.User=(User)sendBody.getObjMessage();
            this.loginframe.dispose();
            mainUI=new Main(this.User);
        }
        if(order.equals(Command.loginreapt)){
            JOptionPane.showMessageDialog(this.loginUI.getFrame(),"重复登录","警告",2);
        }
        if(order.equals(Command.loginfail)){
            JOptionPane.showMessageDialog(this.loginUI.getFrame(),"登录失败","警告",2);
        }
    }
    public void registreceiveordre(SendBody sendBody){
        String order=sendBody.getOrder();
        if(order.equals(Command.registersuccess)){
            JOptionPane.showMessageDialog(this.registerframe,"注册成功");
            if(this.registerframe!=null){
                this.registerframe.dispose();
            }

        }
        if(order.equals(Command.registerfail)){
            JOptionPane.showMessageDialog(this.registerframe,"注册失败");

        }
    }
    public void addfriend(SendBody sendBody){
        String order=sendBody.getOrder();
        if(order.equals(Command.addfriendrequestconfirm)){
            Setings.User user=(Setings.User)sendBody.getObjMessage();
            int i= JOptionPane.showConfirmDialog(this.mainUI,"用户："+sendBody.getSourceID()+" 请求添加好友，是否同意？","提示",JOptionPane.YES_NO_OPTION);
            if(i!=0){
                sendBody.setOrder(Command.addfriendrefuse);
                this.send(sendBody);
                this.addFriend(sendBody.getSourceID());
            }else{
                sendBody.setOrder(Command.addfriendagree);
                this.send(sendBody);

                this.mainUI.addfriend(sendBody.getSourceID());
            }
        }
        if(order.equals(Command.addfriendconfirmagree)){
            Setings.User user=(Setings.User)sendBody.getObjMessage();
            JOptionPane.showMessageDialog(this.mainUI,"用户："+sendBody.getDestID()+" 同意了添加好友请求");
            this.User=user;
            this.mainUI.addfriend(sendBody.getDestID());
        }
        if(order.equals(Command.addfriendconfirmrefuse)){
            JOptionPane.showMessageDialog(this.mainUI,"用户："+sendBody.getDestID()+" 拒绝了添加好友请求");
        }
    }
    public void delfriend(SendBody sendBody){
        String order=sendBody.getOrder();
        if(order.equals(Command.delfriendsuccess)){
            Setings.User user=(Setings.User)sendBody.getObjMessage();
            JOptionPane.showMessageDialog(this.mainUI,"删除用户："+sendBody.getDestID()+" 成功");
            this.User=user;
            this.mainUI.delfriend(sendBody.getDestID());
        }
        if(order.equals(Command.delfriendfail)){
            JOptionPane.showMessageDialog(this.mainUI,"删除用户："+sendBody.getDestID()+" 失败");
        }
        if(order.equals(Command.bedelete)){
            /**
             *
             */
            JOptionPane.showMessageDialog(this.mainUI,"被用户："+sendBody.getSourceID()+" 删除");
            this.mainUI.delfriend(sendBody.getSourceID());
        }
    }
    public void personchat(SendBody sendBody) {
        String order = sendBody.getOrder();
        if (order.equals(Command.sendmessage)) {
            Setings.User user = (Setings.User) sendBody.getObjMessage();
            ChatRoom cr;
            if ((cr = this.findChatRoom(sendBody.getSourceID())) == null) {
                ChatRoom c = new ChatRoom(this.User, sendBody.getSourceID());
                this.addChatRoom(c);
                c.insertmessage(user.getMessage(), user.getStringDate());
            } else {
                cr.insertmessage(user.getMessage(), user.getStringDate());
            }
        }
        if(order.equals(Command.personchatsuccess)){
            Setings.User user=(Setings.User) sendBody.getObjMessage();
            this.User=user;
        }
        if(order.equals(Command.personchatfail)){
            JOptionPane.showMessageDialog(this.mainUI,"聊天失败！");
        }
        if(order.equals(Command.presonchatisiffline)){
            JOptionPane.showMessageDialog(this.mainUI,"用户已离线");

        }

    }
    public void updatehistory(SendBody sendBody){
        String order=sendBody.getOrder();
        if(order.equals(Command.presonchatupdatehistoryreturn)){
            Setings.User user=(Setings.User)sendBody.getObjMessage();
            this.User=user;
            ChatRoom cr;
            if ((cr = this.findChatRoom(sendBody.getDestID())) == null) {
                cr = new ChatRoom(this.User, sendBody.getDestID());
                this.addChatRoom(cr);
            }
            for(int i=0;i<user.getFriendlist().size();i++){
                if(user.getFriendlist().get(i).getFriendId().equals(sendBody.getDestID())){
                    cr.inserthistory(user.getFriendlist().get(i).getMessage());
                }
            }
        }
    }



    public void login(String username,String passwd){
        User user=new User();
        user.setUsername(username);
        user.setPasswd(passwd);
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.login);
        sendBody.setObjMessage(user);
        this.send(sendBody);
    }
    public void logout(){
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.logout);
//        sendBody.setSourceID(User.getUsername());
        this.send(sendBody);
        try{
            this.runflag=false;
            netIn.close();// 关闭网络对象输入流
            netOut.close();// 关闭网络对象输出流
            socket.close();//
            System.exit(0);
        }catch (Exception eclose) {
            System.out.println("客服端退出异常:" + eclose.getMessage());
        }
    }
    public void regist(JFrame jFrame,String username,String passwd,String question,String answer){
        this.registerframe=jFrame;
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.register);
        User user=new User();
        user.setUsername(username);
        user.setPasswd(passwd);
        user.setQuestion(question);
        user.setAnswer(answer);
        sendBody.setObjMessage(user);
        this.send(sendBody);
    }
    public void addFriend(String friendname){
        if(friendname.equals(User.getUsername())){
            JOptionPane.showMessageDialog(this.mainUI,"不能添加自己","警告",2);
            return;
        }
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.addfriend);
        sendBody.setSourceID(User.getUsername());
        sendBody.setDestID(friendname);
        this.send(sendBody);
    }
    public void delFriend(String friendname){
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.delfriend);
        sendBody.setSourceID(User.getUsername());
        sendBody.setDestID(friendname);
        this.send(sendBody);
    }
    public void sendChatMessage(String s,String username,String friendname,String date){
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.personchat);

        this.User.setMessagestatus(true);
        this.User.setMessage(s);

        this.User.setStringDate(date);
        sendBody.setObjMessage(this.User);

        sendBody.setSourceID(username);
        sendBody.setDestID(friendname);
        this.send(sendBody);
    }
    public void addChatRoom(ChatRoom chatRoom){
        if(this.chatRooms==null){
            chatRooms=new LinkedList<>();
        }
        chatRooms.add(chatRoom);
    }
    public ChatRoom findChatRoom(String friendname){
        if(this.chatRooms==null){
            return null;
        }
        for(int i=0;i<this.chatRooms.size();i++){
            if(this.chatRooms.get(i).getFriendname().equals(friendname)){
                return this.chatRooms.get(i);
            }
        }
        return null;
    }
    public void delChatRoom(ChatRoom chatRoom) {
        int num=-1;
        for(int i=0;i<this.chatRooms.size();i++){
            if(this.chatRooms.get(i).getFriendname().equals(chatRoom.getFriendname())) {
                num=i;
                break;
            }
        }
        if(num!=-1){
            this.chatRooms.remove(num);
        }
    }
    public void delChatRoomWithName(String friendname){
        int num=-1;
        ChatRoom temp=null;
        for(int i=0;i<this.chatRooms.size();i++){
            if(this.chatRooms.get(i).getFriendname().equals(friendname)) {
                temp=this.chatRooms.get(i);
                num=i;
                break;
            }
        }
        if(num!=-1){
            this.chatRooms.remove(num);
            temp.dispose();
        }
    }
    public void updateHistory(String username,String friendID){
        SendBody sendBody=new SendBody();
        sendBody.setOrder(Command.presonchatupdatehistory);
        sendBody.setSourceID(username);
        sendBody.setDestID(friendID);
        this.send(sendBody);
    }

    public void function(SendBody sendBody){
        this.loginreceiveorder(sendBody);
        this.registreceiveordre(sendBody);
        this.addfriend(sendBody);
        this.delfriend(sendBody);
        this.personchat(sendBody);
        this.updatehistory(sendBody);
    }
    public static void main(String args[]){
        client=new Client();
        client.init();
    }
}
