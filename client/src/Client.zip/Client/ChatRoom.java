package Client;
import Setings.MessageList;
import Setings.User;

import javax.swing.JFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

public class ChatRoom extends JFrame implements MouseListener, ActionListener,KeyListener,WindowListener {

    private static final long serialVersionUID = 1L;

    private JTextArea viewArea;
    private JTextField viewField;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JLabel jlable;
    private JTextField MyName;
    private Boolean Flag=true;
    private String friendname;
    private User user;
    public ChatRoom(User user,String friendname){
        this.user=user;
        this.friendname=friendname;
        this.setTitle(friendname);
        viewArea = new JTextArea(10, 50);
        viewField = new JTextField(50);
        jlable= new JLabel();   
        jlable.setText("");   
        button1 = new JButton("发送");
        button3=new JButton("查看历史");
        button2 = new JButton("退出");
        MyName = new JTextField();
        MyName.setColumns(30);//控制文本编辑区域字符窗口大小

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2,3,50,50));

        panel.add(MyName);
        panel.add(jlable);
        panel.add(button1);
        panel.add(button3);
        panel.add(button2);  
        JScrollPane sp = new JScrollPane(viewArea);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        this.add("Center",sp);
        this.add("South",panel);
        this.setSize(400,450);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        button1.addActionListener(this);
        button3.addActionListener(this);
        button2.addActionListener(this);
        MyName.addMouseListener(this);
        MyName.addKeyListener(this);
        MyName.requestFocus();
        viewArea.setFocusable(false);
        this.addWindowListener(this);
    }
    public void setFriendname(String friendname){
        this.friendname=friendname;
    }
    public String getFriendname(){
        return this.friendname;
    }
 
    public void mouseClicked(MouseEvent evt) {
        if (evt.getSource() == MyName) {


        }
    }


    public void mousePressed(MouseEvent evt){ }
    public void mouseReleased(MouseEvent evt){ }
    public void mouseEntered(MouseEvent e){

    }
    public void mouseExited(MouseEvent e){ }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String message = "";
        message=MyName.getText();                     //+viewField.getText();
        if(e.getSource()==button1){//发送按钮
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String d=sdf.format(new Date());
            viewArea.setText(viewArea.getText()+d+"\n"+"我: "+message+"\n\n");
            MyName.setText("");
            Client.client.sendChatMessage(message,this.user.getUsername(),this.friendname,d);
        }
        if(e.getSource()==button2){//退出按钮

            this.setVisible(false);
        }
        if(e.getSource()==button3){
            Client.client.updateHistory(this.user.getUsername(),this.friendname);
        }
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }
    @Override
    public void keyPressed(KeyEvent e) {
        String message = "";
        message=MyName.getText();                     //+viewField.getText();
        if(e.getKeyCode()==10){
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String d=sdf.format(new Date());
            viewArea.setText(viewArea.getText()+d+"\n"+"我: "+message+"\n\n");
            Client.client.sendChatMessage(message,this.user.getUsername(),this.friendname,d);
            MyName.setText("");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
//        Client.client.delChatRoomWithName(this.friendname);
        this.setVisible(false);

    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
    public void insertmessage(String message,String d1){
        String m = "";
        String d = d1;
        viewArea.setText(viewArea.getText() + d + "\n" + this.friendname +": "+ message + "\n\n");
        MyName.setText("");
    }
    public void inserthistory(LinkedList<MessageList> messageLists){
        viewArea.setText("");
        if(messageLists!=null) {
            for (int i = 0; i < messageLists.size(); i++) {
                if (messageLists.get(i).getSender().equals(this.friendname)) {
                    if(!messageLists.get(i).getStatus()){
                        viewArea.setText(viewArea.getText() + messageLists.get(i).getDate() +" 未读消息 "+ "\n" + this.friendname + ": " + messageLists.get(i).getMessage() + "\n\n");
                    }else {
                        viewArea.setText(viewArea.getText() + messageLists.get(i).getDate() + "\n" + this.friendname + ": " + messageLists.get(i).getMessage() + "\n\n");
                    }

                } else {
                    viewArea.setText(viewArea.getText() + messageLists.get(i).getDate() + "\n" + "我: " + messageLists.get(i).getMessage() + "\n\n");
                }
                MyName.setText("");
            }
        }
    }
}

